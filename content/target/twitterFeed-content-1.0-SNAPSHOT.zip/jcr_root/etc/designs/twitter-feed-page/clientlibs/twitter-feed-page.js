(function($) {

	var oauth_access_token = '117012393-gZ4crhozO7QHEUlQkI0QMmg9iyCdnm1soS4MMRyE',
            oauth_access_token_secret = 'rmdAK3DEvR6HkVTMM12CghsUTlOFBJBQ02vQQJFSIg',
            consumer_key = 'KbXkX3X9vAPHfIwrkASXdA',
			consumer_secret = '0ljYH0DigNUQ4SOCuXm6NPUAeYdN6zbxzsYHYzmq380';


    $(function() {

        $('#twitterFeedArea').css('color','blue');
        $('.getTweets').text('See if changes are pushed to repository,......');


        



    });






})($CQ || $);
